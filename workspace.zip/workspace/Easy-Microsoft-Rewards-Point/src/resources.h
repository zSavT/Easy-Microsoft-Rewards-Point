/*
 * resources.h
 *
 *  Created on: 25 ago 2023
 *      Author: zSavT
 */

#ifndef SRC_RESOURCES_H_
#define SRC_RESOURCES_H_

#define AppIcon 101

#endif /* SRC_RESOURCES_H_ */
